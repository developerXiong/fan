$(function () {
    var pleasure=[
        {
            title:'南京最好玩的娱乐必去之地',
            imgSrc:'../img/p3.jpg',
            info:'下面我要介绍一下游乐的地方了，下面我要介绍一下游乐的地方了，下面我要介绍一下游乐的地方了，下面我要介绍一下游乐的地方了，下面我要介绍一下游乐的地方了',
            goUrl:'http://www.baidu.com'
        },
        {
            title:'南京最好玩的娱乐必去之地',
            imgSrc:'../img/p3.jpg',
            info:'下面我要介绍一下游乐的地方了，下面我要介绍一下游乐的地方了，下面我要介绍一下游乐的地方了，下面我要介绍一下游乐的地方了，下面我要介绍一下游乐的地方了',
            goUrl:'http://www.baidu.com'
        },
        {
            title:'南京最好玩的娱乐必去之地',
            imgSrc:'../img/p3.jpg',
            info:'下面我要介绍一下游乐的地方了，下面我要介绍一下游乐的地方了，下面我要介绍一下游乐的地方了，下面我要介绍一下游乐的地方了，下面我要介绍一下游乐的地方了',
            goUrl:'http://www.baidu.com'
        },
        {
            title:'南京最好玩的娱乐必去之地',
            imgSrc:'../img/p3.jpg',
            info:'下面我要介绍一下游乐的地方了，下面我要介绍一下游乐的地方了，下面我要介绍一下游乐的地方了，下面我要介绍一下游乐的地方了，下面我要介绍一下游乐的地方了',
            goUrl:'http://www.baidu.com'
        },
        {
            title:'南京最好玩的娱乐必去之地',
            imgSrc:'../img/p3.jpg',
            info:'下面我要介绍一下游乐的地方了，下面我要介绍一下游乐的地方了，下面我要介绍一下游乐的地方了，下面我要介绍一下游乐的地方了，下面我要介绍一下游乐的地方了',
            goUrl:'http://www.baidu.com'
        }
    ]


    let vm = new Vue({
        el:'#container',
        data:{
            pleasure:pleasure
        }
    })


})