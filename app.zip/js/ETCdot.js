$(function () {
    $(".back").click(function () {
        window.history.go(-1)
    })






})